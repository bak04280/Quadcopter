/** Automatically generated file. DO NOT MODIFY */
package com.example.arduinocomm;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}